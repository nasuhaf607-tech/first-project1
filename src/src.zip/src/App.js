import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, useNavigate, Navigate } from "react-router-dom";
import OKUTransport from "./OKUTransport";
import AuthModal from "./AuthModal";
import OKUDashboard from "./roles/OKUDashboard";
import DriverDashboard from "./roles/DriverDashboard";
import CompanyAdminDashboard from "./roles/CompanyAdminDashboard";
import JKMOfficerDashboard from "./roles/JKMOfficerDashboard";

function App() {
  // Auth state: user {name, email, role}
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("currentUser")) || null;
    } catch { return null; }
  });
  // Show login/register modal
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [isRegister, setIsRegister] = useState(false);

  // Logout function
  function handleLogout() {
    setUser(null);
    localStorage.removeItem("currentUser");
  }

  // "Protected route" logic (for demo)
  function ProtectedRoute({ children, role }) {
    if (!user) return <Navigate to="/" replace />;
    if (role && user.role !== role) return <Navigate to="/" replace />;
    return children;
  }

  // After login/register, go to the correct dashboard
  function onAuthSuccess(newUser) {
    setUser(newUser);
    setAuthModalOpen(false);
    localStorage.setItem("currentUser", JSON.stringify(newUser));
    // force location change (works for demo, best to use useNavigate in modal)
    window.location.href = {
      "OKU User": "/oku",
      "Driver": "/driver",
      "Company Admin": "/company-admin",
      "JKM Officer": "/jkm-officer"
    }[newUser.role] || "/";
  }

  return (
    <Router>
      {/* NavBar - styled as in the second row of your image */}
      <nav className="flex justify-between items-center bg-white shadow-md px-6 py-4">
  <h1 className="text-2xl font-bold text-blue-800">
    OKU<span className="font-bold">Transport</span>
  </h1>

  <div className="flex space-x-4 items-center">
    {user && (
      <span className="font-semibold text-blue-800">
        {user.name} ({user.role})
      </span>
    )}
    {user ? (
      <button
        onClick={handleLogout}
        className="bg-blue-800 text-white px-4 py-2 rounded-md font-medium hover:bg-blue-700 transition"
      >
        Log Out
      </button>
    ) : (
      <>
        <button
          onClick={() => {
            setIsRegister(false);
            setAuthModalOpen(true);
          }}
          className="px-4 py-2 rounded-md font-medium text-blue-800 bg-white hover:bg-blue-50 transition"
        >
          Login
        </button>
        <button
          onClick={() => {
            setIsRegister(true);
            setAuthModalOpen(true);
          }}
          className="bg-blue-800 text-white px-4 py-2 rounded-md font-medium hover:bg-blue-700 transition"
        >
          Register
        </button>
      </>
    )}
  </div>
</nav>

      {authModalOpen &&
        <AuthModal isRegister={isRegister}
          onClose={() => setAuthModalOpen(false)}
          onSuccess={onAuthSuccess}
        />
      }
      <Routes>
        <Route path="/" element={<OKUTransport />} />
        <Route path="/oku" element={<ProtectedRoute role="OKU User"><OKUDashboard /></ProtectedRoute>} />
        <Route path="/driver" element={<ProtectedRoute role="Driver"><DriverDashboard /></ProtectedRoute>} />
        <Route path="/company-admin" element={<ProtectedRoute role="Company Admin"><CompanyAdminDashboard /></ProtectedRoute>} />
        <Route path="/jkm-officer" element={<ProtectedRoute role="JKM Officer"><JKMOfficerDashboard /></ProtectedRoute>} />
        <Route path="*" element={<div className="p-8 text-center text-gray-500">404 Not found</div>} />
      </Routes>
    </Router>
  );
}

export default App;
import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMapEvents } from "react-leaflet";
import { useNavigate } from "react-router-dom";
import "leaflet/dist/leaflet.css";

const MapClickHandler = ({ selectionMode, setPickupCoords, setDestinationCoords, setBookingData, bookingData }) => {
  useMapEvents({
    click: async (e) => {
      const lat = e.latlng.lat;
      const lon = e.latlng.lng;

      // Reverse geocoding
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`
      );
      const data = await response.json();
      const placeName = data.display_name || "Unknown location";

      if (selectionMode === "pickup") {
        setPickupCoords([lat, lon]);
        setBookingData({ ...bookingData, pickup: placeName });
      } else if (selectionMode === "destination") {
        setDestinationCoords([lat, lon]);
        setBookingData({ ...bookingData, destination: placeName });
      }
    },
  });
  return null;
};

const OKUPassengerDashboard = () => {
  const [activeTab, setActiveTab] = useState("book-ride");
  const [user, setUser] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [selectionMode, setSelectionMode] = useState("pickup"); // "pickup" or "destination"
  const [currentLocation, setCurrentLocation] = useState([3.139, 101.6869]); // Default KL

  const navigate = useNavigate();

  const [bookingData, setBookingData] = useState({
    pickup: "",
    destination: "",
    date: "",
    time: "",
    specialNeeds: "",
    recurring: false,
    email: "",
  });

  const [pickupCoords, setPickupCoords] = useState(null);
  const [destinationCoords, setDestinationCoords] = useState(null);

  // Load user and bookings
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) {
      setUser(storedUser);
      setBookingData((prev) => ({ ...prev, email: storedUser.email }));
      fetchBookings(storedUser.email);
    } else {
      navigate("/login");
    }

    // Get real-time location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation([position.coords.latitude, position.coords.longitude]);
        },
        (err) => {
          console.error("Error getting location:", err);
        }
      );
    }
  }, [navigate]);

  const fetchBookings = async (email) => {
    try {
      const res = await fetch(`http://localhost/backend/getBook.php?email=${email}`);
      const data = await res.json();
      setBookings(data);
    } catch (error) {
      console.error("Error fetching bookings:", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setBookingData({
      ...bookingData,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost/backend/book.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(bookingData),
      });

      const result = await response.json();
      if (result.success) {
        alert("✅ Booking request submitted successfully!");
        fetchBookings(user.email);

        setBookingData({
          pickup: "",
          destination: "",
          date: "",
          time: "",
          specialNeeds: "",
          recurring: false,
          email: user.email,
        });
        setPickupCoords(null);
        setDestinationCoords(null);
      } else {
        alert("⚠️ Booking failed: " + result.message);
        if (result.message && result.message.toLowerCase().includes("time is already booked")) {
          setBookingData((prev) => ({
            ...prev,
            date: "",
            time: "",
          }));
        }
      }
    } catch (error) {
      console.error("Error:", error);
      alert("❌ Error submitting booking.");
    }
  };

  const today = new Date();
  const upcomingRides = bookings.filter((b) => new Date(b.date) >= today);
  const pastRides = bookings.filter((b) => new Date(b.date) < today);

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-[#f8fafc]">
      {/* Blue Banner */}
      <header className="bg-blue-700 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">OKU Transport Service</h1>
          <div className="flex items-center space-x-4">
            <button
              onClick={handleLogout}
              className="bg-white text-blue-700 px-4 py-2 rounded-lg font-medium hover:bg-blue-100 transition-colors"
            >
              Logout
            </button>
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold border-2 border-white">
              {user?.name ? user.name.charAt(0).toUpperCase() : "P"}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Welcome Banner */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8 text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Welcome, {user?.name || "Passenger"}!
          </h2>
          <p className="text-gray-600">
            How can we assist with your transportation needs today?
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div
            onClick={() => setActiveTab("book-ride")}
            className={`cursor-pointer rounded-xl shadow-md p-6 text-center transition-all ${
              activeTab === "book-ride"
                ? "bg-green-600 text-white ring-2 ring-green-700"
                : "bg-green-100 hover:bg-green-200 text-green-800"
            }`}
          >
            <h3 className="text-lg font-semibold mb-2">🚗 Book a Ride</h3>
            <p>Schedule transportation to your destination</p>
          </div>

          <div
            onClick={() => setActiveTab("upcoming-rides")}
            className={`cursor-pointer rounded-xl shadow-md p-6 text-center transition-all ${
              activeTab === "upcoming-rides"
                ? "bg-blue-600 text-white ring-2 ring-blue-700"
                : "bg-blue-100 hover:bg-blue-200 text-blue-800"
            }`}
          >
            <h3 className="text-lg font-semibold mb-2">📅 My Schedule</h3>
            <p>View and manage your upcoming rides</p>
          </div>

          <div
            onClick={() => setActiveTab("ride-history")}
            className={`cursor-pointer rounded-xl shadow-md p-6 text-center transition-all ${
              activeTab === "ride-history"
                ? "bg-purple-600 text-white ring-2 ring-purple-700"
                : "bg-purple-100 hover:bg-purple-200 text-purple-800"
            }`}
          >
            <h3 className="text-lg font-semibold mb-2">🕓 Ride History</h3>
            <p>Review past trips and feedback</p>
          </div>
        </div>

        {/* Book Ride */}
        {activeTab === "book-ride" && (
          <div className="bg-green-50 rounded-xl shadow-md p-6 mb-8">
            <h3 className="text-xl font-semibold text-green-700 mb-4">Book a New Ride</h3>
            
            {/* Pickup/Destination Buttons */}
            <div className="mb-4 space-x-2">
              <button
                className={`px-4 py-2 rounded-lg font-semibold ${
                  selectionMode === "pickup" ? "bg-green-600 text-white" : "bg-green-100 text-green-800"
                }`}
                onClick={() => setSelectionMode("pickup")}
              >
                Set Pickup
              </button>
              <button
                className={`px-4 py-2 rounded-lg font-semibold ${
                  selectionMode === "destination" ? "bg-blue-600 text-white" : "bg-blue-100 text-blue-800"
                }`}
                onClick={() => setSelectionMode("destination")}
              >
                Set Destination
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                name="pickup"
                value={bookingData.pickup}
                readOnly
                placeholder="Pickup Location"
                className="w-full border p-3 rounded-lg focus:ring focus:ring-green-400"
              />
              <input
                type="text"
                name="destination"
                value={bookingData.destination}
                readOnly
                placeholder="Destination"
                className="w-full border p-3 rounded-lg focus:ring focus:ring-green-400"
              />
              <input
                type="date"
                name="date"
                value={bookingData.date}
                onChange={handleInputChange}
                className="w-full border p-3 rounded-lg focus:ring focus:ring-green-400"
              />
              <input
                type="time"
                name="time"
                value={bookingData.time}
                onChange={handleInputChange}
                className="w-full border p-3 rounded-lg focus:ring focus:ring-green-400"
              />
              <textarea
                name="specialNeeds"
                value={bookingData.specialNeeds}
                onChange={handleInputChange}
                placeholder="Special Needs (optional)"
                className="w-full border p-3 rounded-lg focus:ring focus:ring-green-400"
              />
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  name="recurring"
                  checked={bookingData.recurring}
                  onChange={handleInputChange}
                  className="text-green-600 focus:ring-green-500"
                />
                <span className="text-gray-700">Recurring Ride</span>
              </label>
              <button
                type="submit"
                className="bg-green-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-700"
              >
                Submit Request
              </button>
            </form>

            {/* Map */}
            <div className="mt-4 h-96 rounded-lg overflow-hidden border">
              <MapContainer
                center={currentLocation}
                zoom={13}
                style={{ height: "100%", width: "100%" }}
              >
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                <MapClickHandler
                  selectionMode={selectionMode}
                  setPickupCoords={setPickupCoords}
                  setDestinationCoords={setDestinationCoords}
                  setBookingData={setBookingData}
                  bookingData={bookingData}
                />
                <Marker position={currentLocation}>
                  <Popup>Your Current Location</Popup>
                </Marker>
                {pickupCoords && (
                  <Marker position={pickupCoords}>
                    <Popup>Pickup: {bookingData.pickup}</Popup>
                  </Marker>
                )}
                {destinationCoords && (
                  <Marker position={destinationCoords}>
                    <Popup>Destination: {bookingData.destination}</Popup>
                  </Marker>
                )}
              </MapContainer>
            </div>
          </div>
        )}

        {/* Upcoming Rides */}
        {activeTab === "upcoming-rides" && (
          <div className="bg-blue-50 rounded-xl shadow-md p-6 mb-8">
            <h3 className="text-xl font-semibold text-blue-700 mb-4">Upcoming Rides</h3>
            {upcomingRides.length === 0 ? (
              <p className="text-gray-500">No upcoming rides.</p>
            ) : (
              <ul className="space-y-3">
                {upcomingRides.map((ride, index) => (
                  <li key={index} className="bg-white border rounded-lg p-4 flex justify-between">
                    <div>
                      <p className="font-semibold text-gray-800">
                        {ride.date} at {ride.time}
                      </p>
                      <p className="text-sm text-gray-600">
                        {ride.pickup} → {ride.destination}
                      </p>
                    </div>
                    <span className="bg-green-100 text-green-700 font-bold px-3 py-1 rounded-lg">
                      {ride.status || "Pending"}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        {/* Ride History */}
        {activeTab === "ride-history" && (
          <div className="bg-purple-50 rounded-xl shadow-md p-6 mb-8">
            <h3 className="text-xl font-semibold text-purple-700 mb-4">Ride History</h3>
            {pastRides.length === 0 ? (
              <p className="text-gray-500">No past rides yet.</p>
            ) : (
              <ul className="space-y-3">
                {pastRides.map((ride, index) => (
                  <li key={index} className="bg-white border rounded-lg p-4">
                    <p className="font-semibold text-gray-800">
                      {ride.date} at {ride.time}
                    </p>
                    <p className="text-sm text-gray-600">
                      {ride.pickup} → {ride.destination}
                    </p>
                    {ride.rating && (
                      <p className="text-yellow-500 font-semibold">⭐ {ride.rating}/5</p>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </main>
    </div>
  );
};

export default OKUPassengerDashboard;
